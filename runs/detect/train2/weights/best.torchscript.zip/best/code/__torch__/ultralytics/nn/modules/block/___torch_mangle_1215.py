class DFL(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_1214.Conv2d
  def forward(self: __torch__.ultralytics.nn.modules.block.___torch_mangle_1215.DFL,
    x: Tensor) -> Tensor:
    conv = self.conv
    b = ops.prim.NumToTensor(torch.size(x, 0))
    _0 = int(b)
    _1 = int(b)
    a = ops.prim.NumToTensor(torch.size(x, 2))
    _2 = int(a)
    _3 = torch.transpose(torch.view(x, [_1, 4, 16, int(a)]), 2, 1)
    input = torch.softmax(_3, 1)
    distance = torch.view((conv).forward(input, ), [_0, 4, _2])
    return distance
